#ifndef SORT_H
#define SORT_H
#include<vector>
class Sort{
    public:
    std::vector<int> sort(std::vector<int> list);
};
#endif